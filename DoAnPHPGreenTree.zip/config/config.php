<?php
// define('HOST', '');
// define('USERNAME', 'root');
// define('PASSWORD', '');
// define('DATABASE', 'db_green_treee');


define('HOST', 'sql103.infinityfree.com');
define('USERNAME', 'if0_40653111');
define('PASSWORD', 'DsAlYh3lTo7');
define('DATABASE', 'if0_40653111_db_green_treee');
?>