<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Green Tree</title>
  <style>
    body {
      margin: 0;
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f6f5;
      color: #333;
    }

    /* Header */
    .header {
      position: fixed;
      top: 0; left: 0; right: 0;
      z-index: 1000;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 40px;
      background: linear-gradient(90deg, #ffffff, #f9f9f9);
      box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }

    .logo {
      font-size: 22px;
      font-weight: bold;
      color: #2e7d32;
      letter-spacing: 1px;
    }

    .search-bar {
      display: flex;
      align-items: center;
      flex-grow: 1;
      margin: 0 40px;
      background: #fff;
      border: 1px solid #ddd;
      border-radius: 25px;
      padding: 5px 10px;
    }

    .search-bar select, .search-bar input {
      border: none;
      outline: none;
      font-size: 15px;
      background: transparent;
    }

    .search-bar select {
      margin-right: 10px;
      color: #555;
    }

    .search-bar input {
      flex-grow: 1;
      padding: 8px;
    }

    .search-bar::after {
      content: "🔍";
      margin-left: 10px;
      color: #2e7d32;
    }

    .contact {
      font-size: 14px;
      color: #444;
      font-weight: 500;
    }

    .nav_login a {
      text-decoration: none;
      color: #2e7d32;
      font-weight: 600;
    }

    /* Nav */
    .nav {
      position: fixed;
      top: 75px;
      left: 0; right: 0;
      z-index: 999;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background-color: #ffffff;
      padding: 12px 40px;
      border-top: 1px solid #eee;
      box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .nav-left a, .nav-right a {
      margin: 0 15px;
      text-decoration: none;
      color: #333;
      font-weight: 500;
      transition: color 0.3s, border-bottom 0.3s;
    }

    .nav-left a:hover, .nav-right a:hover {
      color: #2e7d32;
      border-bottom: 2px solid #2e7d32;
    }

    /* Body */
    .than_body {
      margin-top: 140px;
      padding: 40px;
      min-height: 100vh;
    }

    .gioithieu {
      background: #fff;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.05);
    }

    .gioithieu h2 {
      color: #2e7d32;
      margin-bottom: 15px;
    }

    .gioithieu p {
      line-height: 1.6;
      color: #555;
    }
    .gioithieu {
  background: #ffffff;
  padding: 60px 80px;
  border-radius: 12px;
  box-shadow: 0 6px 18px rgba(0,0,0,0.06);
}

/* Tiêu đề lớn */
.gt-title {
  text-align: center;
  font-size: 34px;
  font-weight: 700;
  color: #2e7d32;
  margin-bottom: 8px;
}

/* Dòng mô tả dưới tiêu đề */
.gt-sub {
  text-align: center;
  font-size: 15px;
  color: #777;
  margin-bottom: 45px;
}

/* Layout 2 cột */
.gt-content {
  display: flex;
  align-items: center;
  gap: 60px;
}

/* Cột chữ bên trái */
.gt-text {
  flex: 1;
}

.gt-text h3 {
  font-size: 22px;
  font-weight: 600;
  color: #2e7d32;
  margin-bottom: 18px;
}

.gt-text p {
  font-size: 15px;
  line-height: 1.8;
  color: #555;
  margin-bottom: 18px;
}

/* Cột ảnh bên phải */
.gt-image {
  flex: 1;
}

.gt-image img {
  width: 100%;
  height: 380px;
  object-fit: cover;
  border-radius: 14px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.15);
}
  </style>
</head>
<body>
  <div class="header">
    <div class="logo">🌿 Green Tree</div>
    <div class="search-bar">
      <select>
        <option>Tất cả danh mục</option>
        <option>Cây trong nhà</option>
        <option>Cây văn phòng</option>
        <option>Cây phong thủy</option>
      </select>
      <input type="text" placeholder="Tìm kiếm sản phẩm...">
    </div>
    <div class="contact">📞 0345 530 628</div>
    <div class="nav_login"><a href="../index.php">👤 Đăng kí / Đăng nhập</a></div>
  </div>

  <div class="nav">
    <div class="nav-left">
      <a href="trangchu.php">🏠️ Trang chủ</a>
      <a href="#">ⓘ Giới thiệu</a>
      <a href="sanpham.php">🛍️ Sản phẩm</a>
    </div>
    <div class="nav-right">
      <a href="#" onclick="alert('Bạn cần đăng nhập trước.')">🧾 Đơn mua</a>
      <a href="#" onclick="alert('Bạn cần đăng nhập trước.')">🛒 Giỏ hàng</a>
    </div>
  </div>

    <div class="than_body">
  

      <div class="gioithieu">
        <h2 class="gt-title">Về Chúng Tôi</h2>
    <p class="gt-sub">
      Mang thiên nhiên đến gần bạn hơn với những loại cây cảnh cao cấp.
    </p>

        <div class="gt-content">
              <div class="gt-text">
                <h3>Chúng Tôi Là Ai</h3>
                <p>
                  Tại Green Home, chúng tôi đam mê kết nối con người với vẻ đẹp của thiên nhiên.
                  Niềm tin của chúng tôi là cung cấp những loại cây chất lượng cao
                  và giải pháp làm vườn giúp biến không gian sống của bạn thành những
                  ốc đảo xanh tươi.
                </p>
                <p>
                  Dù bạn là người yêu thiên nhiên hay mới bắt đầu,
                  chúng tôi luôn sẵn sàng đồng hành cùng bạn trên từng bước đường.
                  Từ cây trồng trong nhà đến cảnh quan ngoài trời,
                  chúng tôi có mọi thứ bạn cần để tạo nên khu vườn mơ ước.
                </p>
              </div>

          <div class="gt-image">
        <img src="https://newstore24h.com/wp-content/uploads/2024/12/thiet-ke-cua-hang-cay-canh-42.jpg" alt="Green Tree">
      </div>
    </div>
    </div>
  </div>
</body>
</html>
